/// Atividade 1: Declaração e Tipos de Variáveis

// Informações da padaria
const nomePadaria = "Padaria Doce Sabor"; // Usando const para valor que não muda
const endereco = "Rua das Flores, 123";
const telefone = "(11) 1234-5678";

// Preços dos produtos
let precoPaoFrances = 0.50; // Usando let para valores que podem mudar
let precoBolo = 25.90; // Exemplo de preço com decimal
let precoSalgado = 3.50; // Outro exemplo de preço

// Controle de estoque
let estoquePao = 100; // Quantidade inicial de pão
let estoqueBolo = 5; // Quantidade inicial de bolo
let estoqueSalgado = 20; // Quantidade inicial de salgado

// Arrays de produtos e categorias
const produtos = ["Pão Francês", "Bolo de Chocolate", "Coxinha", "Brigadeiro"];
const categorias = ["Pães", "Bolos", "Salgados", "Doces"];

// Objeto produto completo
const produtoObjeto = { // Renomeado para evitar conflito com array 'produtos'
   nome: "Pão Francês",
   preco: 0.50,
   categoria: "Pães",
   estoque: 100,
   ingredientes: ["Farinha", "Água", "Sal", "Fermento"]
};

// Exemplo de var (não recomendado, mas para demonstração)
var descricaoPadaria = "A melhor padaria da cidade";

// Constante que não pode ser alterada
const anoFundacao = 1990;

// Let que pode ser reatribuída
let clientesHoje = 0;
clientesHoje = 15; // Pode ser reatribuída


// Atividade 3: Manipulação de Strings e Dados

// Formatação de nomes
function formatarNome(nome) {
 return nome.toLowerCase()
 .split(' ')
 .map(palavra => palavra.charAt(0).toUpperCase() + palavra.slice(1))
 .join(' ');
}

// Formatação de preços
function formatarPreco(preco) {
 return `R$ ${preco.toFixed(2).replace('.', ',')}`;
}

// Sistema de códigos de produto
function gerarCodigoProduto(categoria, numero) {
 const prefixos = {
 'Pães': 'PAO',
 'Bolos': 'BOLO',
 'Salgados': 'SALG',
 'Doces': 'DOCE'
 };

 const prefixo = prefixos[categoria] || 'PROD';
 const numeroFormatado = numero.toString().padStart(3, '0');
 return `${prefixo}${numeroFormatado}`;
}

// Testando tipos (usando console.log para depuração)
console.log("--- Atividade 1 Debug ---");
console.log("Nome da padaria:", nomePadaria, "Tipo:", typeof nomePadaria);
console.log("Preço do pão:", precoPaoFrances, "Tipo:", typeof precoPaoFrances);
console.log("Produtos:", produtos, "Tipo:", typeof produtos);
// console.log("Produto completo:", produto, "Tipo:", typeof produto); // Removido pois 'produto' não está definido
console.log("Produto Objeto:", produtoObjeto, "Tipo:", typeof produtoObjeto); // Usando o nome renomeado
console.log("Estoque definido?", estoquePao !== undefined);
console.log("Ano de Fundação:", anoFundacao);
console.log("Clientes Hoje:", clientesHoje);
console.log("------------------------");

// Mensagens dinâmicas
function criarMensagemBoasVindas(nomeCliente, horario) {
 const nome = formatarNome(nomeCliente);
 let saudacao;

 if (horario < 12) {
 saudacao = "Bom dia";
 } else if (horario < 18) {
 saudacao = "Boa tarde";
 } else {
 saudacao = "Boa noite";
 }

 return `${saudacao}, ${nome}! Bem-vindo à Padaria Doce Sabor!`;
}

// Validação básica
function validarEntrada(valor, tipo) {
 if (!valor || typeof valor === 'string' && valor.trim() === '') {
 return { valido: false, erro: "Campo não pode estar vazio" };
 }

 if (tipo === 'numero') {
 const numero = parseFloat(valor);
 if (isNaN(numero) || numero < 0) {
 return { valido: false, erro: "Deve ser um número positivo" };
 }
 return { valido: true, valor: numero };
 }

 if (tipo === 'texto') {
 if (typeof valor !== 'string' || valor.length < 2) {
 return { valido: false, erro: "Texto muito curto ou formato inválido" };
 }
 return { valido: true, valor: valor.trim() };
 }

 return { valido: true, valor: valor };
}

// Sistema de busca simples
function buscarProduto(lista, termo) {
 const termoBusca = termo.toLowerCase();
 return lista.filter(produto =>
 produto.toLowerCase().includes(termoBusca)
 );
}

// Formatação de data e hora
function formatarDataHora() {
 const agora = new Date();
 const data = agora.toLocaleDateString('pt-BR');
 const hora = agora.toLocaleTimeString('pt-BR');

 return `${data} às ${hora}`;
}

console.log("--- Atividade 3 Debug ---");
console.log("Nome formatado:", formatarNome("joão silva santos"));
console.log("Preço formatado:", formatarPreco(25.9));
console.log("Código do produto:", gerarCodigoProduto("Pães", 1));
console.log("Mensagem de boas-vindas:", criarMensagemBoasVindas("maria santos", 14));

const validacaoNumero = validarEntrada("25.50", "numero");
console.log("Validação número:", validacaoNumero);

const validacaoTexto = validarEntrada("ab", "texto");
console.log("Validação texto:", validacaoTexto);

const listaDeProdutosBusca = ["Pão Francês", "Pão de Açúcar", "Bolo de Chocolate"];
console.log("Busca por 'pão':", buscarProduto(listaDeProdutosBusca, "pão"));

console.log("Data/Hora atual:", formatarDataHora());
console.log("------------------------");


// Atividade 5: Objetos e Estruturas Complexas
// Exemplo de Objeto Produto Completo (Atualizado)
const produtoExemplo = {
   id: 1,
   nome: "Pão Francês",
   preco: 0.50,
   categoria: "Pães",
   estoque: 100,
   ingredientes: ["Farinha", "Água", "Sal", "Fermento"],
   informacaoNutricional: {
   	calorias: 150,
   	carboidratos: 30,
   	proteinas: 5,
   	gorduras: 2
   },
   disponivel: true,

   // Método do objeto
   atualizarEstoque: function(quantidade) {
   	this.estoque += quantidade;
   }
};

// Objeto Cliente
const clienteExemplo = {
  nome: "Fernanda Costa",
  telefone: "(11) 5555-5555",
  pontos: 50,
  historicoPedidos: [] // Array para armazenar objetos pedido
};

// Objeto Pedido
const pedidoExemplo = {
  id: "PED001",
  cliente: clienteExemplo, // Referência ao objeto cliente
  itens: [
    { produto: produtoExemplo, quantidade: 2, subtotal: 1.00 } // Pode usar o objeto produto aqui
  ],
  total: 1.00,
  status: "Em preparo", // Ex: "Em preparo", "Finalizado", "Cancelado"
  dataHora: new Date() // Objeto Date para data e hora
};

// Objeto Padaria
const padaria = {
  nome: "Padaria Doce Sabor",
  endereco: "Rua das Flores, 123",
  telefone: "(11) 1234-5678",
  produtos: [], // Array de objetos produto
  clientes: [], // Array de objetos cliente
  pedidosDoDia: [] // Array de objetos pedido
};

// Objeto de Configurações
const configuracoes = {
  taxasCambio: { dolar: 5.20, euro: 6.10 },
  descontosPorQuantidade: [ { min: 10, percentual: 0.15 }, { min: 5, percentual: 0.10 }, { min: 3, percentual: 0.05 } ],
  impostoPercentual: 0.08,
  taxaEntregaFixa: 5.00
};

// Atividade 2: Operações Matemáticas e Calculadora

// Obtém referências aos elementos do formulário (IDs do index.html)
const produtoSelect = document.getElementById('produto');
const quantidadeInput = document.getElementById('quantidade');
const valorPagoInput = document.getElementById('valorPago');
const clienteFidelidadeSelect = document.getElementById('clienteFidelidade'); // Referência para o dropdown de cliente
const usarPontosCheckbox = document.getElementById('usarPontos'); // Referência para o checkbox de usar pontos
const calcularBtn = document.querySelector('#calculadoraForm button[type="submit"]'); // Obtém a referência correta do botão
const resultadoDiv = document.getElementById('resultadoCalculo');

// Adiciona um event listener ao botão de calcular
calcularBtn.addEventListener('click', function(event) {
    // Previne o comportamento padrão do formulário (recarregar a página)
    event.preventDefault();

    // Obtém os valores dos inputs
    const produtoSelecionado = produtoSelect.value;
    const quantidade = parseInt(quantidadeInput.value);
    const valorPago = parseFloat(valorPagoInput.value);
    const indiceClienteSelecionado = clienteFidelidadeSelect.value; // Obtém o índice do cliente selecionado
    const usarPontos = usarPontosCheckbox.checked; // Verifica se o checkbox está marcado


    // --- Validações ---
    if (isNaN(quantidade) || quantidade <= 0) {
        resultadoDiv.textContent = "Por favor, insira uma quantidade válida.";
        return;
    }

    if (isNaN(valorPago) || valorPago < 0) {
        resultadoDiv.textContent = "Por favor, insira um valor pago válido e não negativo.";
        return;
    }
    // --- Fim das Validações ---


    // Obtém o preço do produto selecionado. Usamos o objeto 'precos' que deve estar
    // acessível globalmente pois calculadora.js é carregado antes deste script.
    // Adicionamos uma verificação para garantir que 'precos' existe.
    let precoUnitario = 0;
    switch (produtoSelecionado) {
        case 'paoFrances':
            // Verifica se 'precos' e 'precos.paoFrances' existem antes de acessar
            precoUnitario = (typeof precos !== 'undefined' && precos.paoFrances !== undefined) ? precos.paoFrances : 0; break;
        case 'bolo':
            precoUnitario = precos.bolo;
            break;
        case 'coxinha':
            precoUnitario = precos.coxinha;
            break;
        case 'brigadeiro':
            precoUnitario = precos.brigadeiro;
            break;
    }

    // Calcula o subtotal usando a função de calculadora.js
    // Verificamos se a função calcularSubtotal existe antes de chamar
    let subtotal = (typeof calcularSubtotal === 'function') ? calcularSubtotal(precoUnitario, quantidade) : 0;


    // --- Lógica para Descontos por Volume, Impostos e Taxa de Entrega ---
    let descontoAplicadoVolume = 0; // Renomeado para clareza
    const descontosOrdenados = configuracoes.descontosPorQuantidade.sort((a, b) => b.min - a.min);

    for (const desconto of descontosOrdenados) {
        if (quantidade >= desconto.min) {
            descontoAplicadoVolume = subtotal * desconto.percentual;
            subtotal -= descontoAplicadoVolume; // Aplica o desconto ao subtotal
            break; // Aplica apenas o maior desconto encontrado e sai do loop
        }
    }

    const valorImposto = subtotal * configuracoes.impostoPercentual;
    const totalComImposto = subtotal + valorImposto;

    const taxaEntrega = configuracoes.taxaEntregaFixa;
    let totalFinal = totalComImposto + taxaEntrega;
    // --- Fim da Lógica de Descontos por Volume, Impostos e Taxa de Entrega ---

    // --- Lógica para Pontos de Fidelidade ---
    let descontoPontosAplicado = 0;
    let mensagemPontos = "";

    // Verifica se um cliente foi selecionado e se o checkbox de usar pontos está marcado
    if (indiceClienteSelecionado !== "" && usarPontos) {
        const clienteSelecionado = clientesFrequentes[parseInt(indiceClienteSelecionado)]; // Obtém o objeto cliente

        if (clienteSelecionado && clienteSelecionado.pontos > 0) {
            // Calcula o desconto de pontos a ser aplicado (limitado ao totalFinal)
            descontoPontosAplicado = Math.min(totalFinal, clienteSelecionado.pontos);
            totalFinal -= descontoPontosAplicado; // Aplica o desconto dos pontos
            mensagemPontos = ` (-${formatarPreco(descontoPontosAplicado)} usando pontos)`;

            // Nota: A lógica para DEDUZIR os pontos do saldo do cliente
            // e ADICIONAR novos pontos baseados na compra final
            // seria feita após a confirmação do pedido, não apenas no cálculo inicial.
            // Por enquanto, apenas calculamos o desconto para exibição.
        } else if (clienteSelecionado && clienteSelecionado.pontos === 0) {
             mensagemPontos = " (Cliente selecionado não possui pontos para usar)";
        }
    }
    // --- Fim da Lógica para Pontos de Fidelidade ---


    // --- Lógica para Cálculo do Troco ---
    let troco = 0;
    let mensagemTroco = "";

    if (valorPago >= totalFinal) {
        troco = valorPago - totalFinal;
        mensagemTroco = `Troco: ${formatarPreco(troco)}`;
    } else {
        const faltando = totalFinal - valorPago;
        mensagemTroco = `Faltando: ${formatarPreco(faltando)}`;
    }
    // --- Fim da Lógica de Cálculo do Troco ---


    // Exibe o resultado completo
    let resultadoTexto = `Subtotal: ${formatarPreco(subtotal + descontoAplicadoVolume)}`; // Exibe o subtotal antes do desconto por volume
    if (descontoAplicadoVolume > 0) {
        resultadoTexto += ` (-${formatarPreco(descontoAplicadoVolume)} de desconto por volume)`;
    }
     resultadoTexto += `<br>Imposto (${(configuracoes.impostoPercentual * 100).toFixed(0)}%): ${formatarPreco(valorImposto)}`;
    resultadoTexto += `<br>Taxa de Entrega: ${formatarPreco(taxaEntrega)}`;
    resultadoTexto += `<br><strong>Total antes dos pontos: ${formatarPreco(totalComImposto + taxaEntrega)}</strong>`; // Exibe o total antes do desconto de pontos

    if (descontoPontosAplicado > 0) {
         resultadoTexto += `${mensagemPontos}`; // Adiciona a mensagem de desconto de pontos
    } else if (usarPontos && indiceClienteSelecionado !== "") {
         resultadoTexto += `${mensagemPontos}`; // Adiciona a mensagem se o cliente selecionado não tem pontos
    }


    resultadoTexto += `<br><strong>Total Final: ${formatarPreco(totalFinal)}</strong>`;
    resultadoTexto += `<br>Valor Pago: ${formatarPreco(valorPago)}`;
    resultadoTexto += `<br>${mensagemTroco}`;


    resultadoDiv.innerHTML = resultadoTexto;

});


// Array de produtos disponíveis
let produtosDisponiveis = [
   "Pão Francês",
   "Bolo de Chocolate",
   "Coxinha",
   "Brigadeiro",
   // Adicionados para a lista de produtos disponíveis
   "Pão de Queijo",
   "Pão de Açúcar",
   "Torta de Frango"
];

// Sistema de carrinho de compras
let carrinho = [];

function adicionarAoCarrinho(produto, quantidade = 1) {
   const itemExistente = carrinho.find(item => item.produto === produto);

   if (itemExistente) {
       itemExistente.quantidade += quantidade;
   } else {
       carrinho.push({ produto, quantidade });
   }

   atualizarCarrinhoHTML();
   console.log(`${produto} adicionado ao carrinho`);
}

function removerDoCarrinho(produto) {
   const index = carrinho.findIndex(item => item.produto === produto);

   if (index !== -1) { // Verifica se o produto foi encontrado
       carrinho.splice(index, 1);

       atualizarCarrinhoHTML();

   	console.log(`${produto} removido do carrinho`);
   }
}

function verCarrinho() {
   if (carrinho.length === 0) {
   	console.log("Carrinho vazio");
   	return;
   }

   console.log("Itens no carrinho:");
   carrinho.forEach(item => {
   	console.log(`- ${item.produto}: ${item.quantidade}x`);
   });
}

// Lista de clientes frequentes
let clientesFrequentes = [
   { nome: "Maria Silva", telefone: "(11) 1111-1111", pontos: 150 },
   { nome: "João Santos", telefone: "(11) 2222-2222", pontos: 89 },
   { nome: "Ana Costa", telefone: "(11) 3333-3333", pontos: 200 }
];

// Função para atualizar a exibição dos clientes no HTML e preencher o dropdown da calculadora
function atualizarClientesHTML() {
    const listaClientes = document.getElementById('clientesLista');
    const selectClientesCalculadora = document.getElementById('clienteFidelidade'); // Referência para o dropdown na calculadora

    if (!listaClientes) {
        console.error("Elemento #clientesLista não encontrado no HTML.");
        return;
    }
    listaClientes.innerHTML = ''; // Limpa a lista atual

     if (!selectClientesCalculadora) {
        console.error("Elemento #clienteFidelidade não encontrado no HTML.");
        // Continuamos atualizando a lista de clientes, mas o dropdown não será preenchido
     } else {
         selectClientesCalculadora.innerHTML = '<option value="">-- Selecione o cliente --</option>'; // Limpa e adiciona a opção padrão
     }


    clientesFrequentes.forEach((cliente, index) => {
        // Atualiza a lista de clientes (como já fazia)
        const li = document.createElement('li');
        const nomeSpan = document.createElement('span');
        nomeSpan.textContent = formatarNome(cliente.nome);

        const pontosSpan = document.createElement('span');
        pontosSpan.textContent = ` - Pontos: ${cliente.pontos}`;\n
        li.appendChild(nomeSpan);
        li.appendChild(pontosSpan);
        listaClientes.appendChild(li);

        // Adiciona a opção ao dropdown da calculadora
        if (selectClientesCalculadora) {
            const option = document.createElement('option');
            // Usamos o índice como value para facilitar a recuperação do objeto cliente no array
            option.value = index;
            option.textContent = formatarNome(cliente.nome) + ` (${cliente.pontos} pts)`; // Exibe nome e pontos
            selectClientesCalculadora.appendChild(option);
        }
    });
}


function adicionarCliente(nome, telefone) {
   const novoCliente = {

   	nome: formatarNome(nome), // Usando a função de formatação da Atividade 3
   	telefone: telefone,
   	pontos: 0
   };

   clientesFrequentes.push(novoCliente);
   console.log(`Cliente ${nome} adicionado`);
   atualizarClientesHTML(); // Atualiza a exibição dos clientes na página e o dropdown da calculadora
}

// Histórico de pedidos do dia
let historicoPedidos = []; // Renomeado para clareza

function registrarPedido(cliente, itens, total) {
   const pedido = {
   	cliente: cliente,
   	itens: [...itens], // Cópia do array
   	total: total,
   	horario: formatarDataHora() // Usando a função de formatação da Atividade 3
   };

   historicoPedidos.push(pedido);
}

// Sistema de favoritos
let produtosFavoritos = [];

function adicionarFavorito(produto) {
   if (!produtosFavoritos.includes(produto)) {
       produtosFavoritos.push(produto);
   	console.log(`${produto} adicionado aos favoritos`);
    atualizarFavoritosHTML(); // Atualiza a exibição dos favoritos na página
   } else {
   	console.log(`${produto} já está nos favoritos`);
   }
}

// Ranking de produtos mais vendidos
let vendasProdutos = {};

function registrarVenda(produto, quantidade) {
   if (vendasProdutos[produto]) {
       vendasProdutos[produto] += quantidade;
   } else {
       vendasProdutos[produto] = quantidade;
   }
}


// Função para obter o ranking (definida no exemplo, mas não adicionada anteriormente)
function obterRanking() {
   const ranking = Object.entries(vendasProdutos)
       .sort((a, b) => b[1] - a[1])
       .map(([produto, vendas]) => ({ produto, vendas }));

 return ranking;
}

// Sistema de notificações
// O array notificacoes já foi declarado
let notificacoes = [];

function adicionarNotificacao(mensagem, tipo = 'info') {
    notificacoes.push({ mensagem, tipo, timestamp: new Date() });
    atualizarNotificacoesHTML(); // Atualiza a exibição das notificações
    console.log(`Notificação (${tipo}): ${mensagem}`);
    // Opcional: Adicionar lógica para remover notificações antigas após um tempo
}

// Exemplos de uso da Atividade 4 - Chamadas para popular dados iniciais e testar

// Atividade 6: Interação com o Usuário - Eventos (Exemplo de Formulário de Cliente)

// Obtém referências aos elementos do formulário de cliente
const formularioCliente = document.getElementById('cadastroClienteForm'); // Assume que o formulário tem este ID
const nomeClienteInput = document.getElementById('nomeCliente'); // Assume que o input de nome tem este ID
const telefoneClienteInput = document.getElementById('telefoneCliente'); // Assume que o input de telefone tem este ID
const mensagemClienteDiv = document.getElementById('mensagemCadastroCliente'); // Corrigido o ID para mensagemCadastroCliente

// Adiciona um event listener para o envio do formulário
if (formularioCliente) { // Verifica se o formulário existe antes de adicionar o listener
    formularioCliente.addEventListener('submit', function(event) {
        event.preventDefault(); // Previne o recarregamento da página

        const nome = nomeClienteInput.value;
        const telefone = telefoneClienteInput.value;

        // Opcional: Adicionar validação básica
        const validacaoNome = validarEntrada(nome, 'texto');
        const validacaoTelefone = validarEntrada(telefone, 'texto'); // Pode ser melhorada para validar formato de telefone

        if (validacaoNome.valido && validacaoTelefone.valido) {
            adicionarCliente(validacaoNome.valor, validacaoTelefone.valor); // Adiciona o cliente formatado
            if (mensagemClienteDiv) mensagemClienteDiv.textContent = 'Cliente cadastrado com sucesso!';
            nomeClienteInput.value = ''; // Limpa o campo de nome
            telefoneClienteInput.value = ''; // Limpa o campo de telefone
            adicionarNotificacao(`Novo cliente cadastrado: ${validacaoNome.valor}`, "sucesso"); // Exibe notificação
        } else {
            if (mensagemClienteDiv) mensagemClienteDiv.textContent = `Erro no cadastro: ${validacaoNome.erro || validacaoTelefone.erro}`;
            adicionarNotificacao(`Erro no cadastro de cliente`, "erro"); // Exibe notificação de erro
        }
    });
} else {
    console.error("Formulário de cadastro de cliente não encontrado (ID #cadastroClienteForm).");
}




// Função para atualizar a exibição dos clientes no HTML

// Função para atualizar a exibição dos favoritos no HTML


// O array notificacoes já foi declarado
let notificacoes = [];

function atualizarCarrinhoHTML() {
  const listaCarrinho = document.getElementById('carrinhoLista');
  if (!listaCarrinho) {
    console.error("Elemento #carrinhoLista não encontrado no HTML.");
    return;
  }

  listaCarrinho.innerHTML = ''; // Limpa a lista atual

  if (carrinho.length === 0) {
    const li = document.createElement('li');
    li.textContent = "Carrinho vazio.";
    listaCarrinho.appendChild(li);
    return;
  }

  carrinho.forEach(item => {
    const li = document.createElement('li');
    li.classList.add('item-carrinho'); // Adiciona uma classe para estilização

    // Encontrar o preço do produto usando o objeto precos de calculadora.js
    // Mapeamento simples para obter o preço com base no nome do produto
    const mapeamentoNomesPrecos = {
        "Pão Francês": precos.paoFrances,
        "Bolo de Chocolate": precos.bolo,
        "Coxinha": precos.coxinha,
        "Brigadeiro": precos.brigadeiro
        // Adicionar outros produtos conforme necessário
    };

    const conversaoMoedaDiv = document.getElementById('conversaoMoeda');
// Função para converter Real para outras moedas
function converterMoeda(valorEmReais) {
    // Verifica se o objeto configuracoes e as taxas de cambio existem
    if (typeof configuracoes === 'undefined' || !configuracoes.taxasCambio) {
        console.error("Objeto de configurações ou taxas de câmbio não encontrados.");
        return { dolar: NaN, euro: NaN }; // Retorna NaN se as taxas não estiverem disponíveis
    }
    const taxas = configuracoes.taxasCambio;

    // Verifica se as taxas de câmbio para dolar e euro existem
    if (taxas.dolar === undefined || taxas.euro === undefined) {
         console.error("Taxas de câmbio para Dólar ou Euro não encontradas nas configurações.");
         return { dolar: NaN, euro: NaN };
    }

    const valorEmDolar = valorEmReais / taxas.dolar;
    const valorEmEuro = valorEmReais / taxas.euro;

    return {
        dolar: valorEmDolar,
        euro: valorEmEuro
    };
}
// --- Lógica para Conversão de Moeda ---
const totaisConvertidos = converterMoeda(totalFinal);

// Limpa a área de conversão antes de exibir os novos resultados
if (conversaoMoedaDiv) {
    conversaoMoedaDiv.innerHTML = '';

    // Verifica se a conversão foi bem-sucedida (não retornou NaN)
    if (!isNaN(totaisConvertidos.dolar) && !isNaN(totaisConvertidos.euro)) {
         const pTitulo = document.createElement('p');
        pTitulo.textContent = 'Valores Convertidos:';
        pTitulo.style.fontWeight = 'bold'; // Opcional: Negrito para o título
        conversaoMoedaDiv.appendChild(pTitulo);

        const pDolar = document.createElement('p');
        pDolar.textContent = `Total em Dólar: $${totaisConvertidos.dolar.toFixed(2)}`; // Formata para 2 casas decimais
        conversaoMoedaDiv.appendChild(pDolar);

        const pEuro = document.createElement('p');
        pEuro.textContent = `Total em Euro: €${totaisConvertidos.euro.toFixed(2)}`; // Formata para 2 casas decimais
        conversaoMoedaDiv.appendChild(pEuro);
    } else {
        // Exibe uma mensagem de erro se a conversão não foi possível
         const pErro = document.createElement('p');
         pErro.textContent = 'Não foi possível realizar a conversão de moeda. Verifique as configurações.';
         pErro.style.color = 'red'; // Opcional: Cor vermelha para o erro
         conversaoMoedaDiv.appendChild(pErro);
    }
}
// --- Fim da Lógica para Conversão de Moeda ---

// Product Gallery Code Starts Here
// --- Inicialização ---
      // Carregar e exibir os produtos na galeria ao carregar a página
      // Certifique-se de que 'listaDeTodosOsProdutos' está definido em seu script.js
      if (typeof listaDeTodosOsProdutos !== 'undefined' && Array.isArray(listaDeTodosOsProdutos)) {
        exibirProdutosGaleria(listaDeTodosOsProdutos);
   } else {
        console.error("Array 'listaDeTodosOsProdutos' não encontrado ou não é um array no script.js.");
         // Fallback: exibir produtosDisponiveis com detalhes fictícios se listaDeTodosOsProdutos não estiver disponível
         if (typeof produtosDisponiveis !== 'undefined' && Array.isArray(produtosDisponiveis)) {
              const produtosComDetalhesParaGaleria = produtosDisponiveis.map(nomeProduto => {
                  const precosExemplo = { "Pão Francês": 0.50, "Bolo de Chocolate": 25.90, "Coxinha": 3.50, "Brigadeiro": 2.50, "Pão de Queijo": 1.50, "Pão de Açúcar": 1.00, "Torta de Frango": 15.00 }; // Exemplo
                  const estoquesExemplo = { "Pão Francês": 100, "Bolo de Chocolate": 5, "Coxinha": 20, "Brigadeiro": 50, "Pão de Queijo": 80, "Pão de Açúcar": 120, "Torta de Frango": 10 }; // Exemplo
                   const imagemUrlsExemplo = { "Pão Francês": "placeholder-pao.png", "Bolo de Chocolate": "placeholder-bolo.png", "Coxinha": "placeholder-coxinha.png", "Brigadeiro": "placeholder-brigadeiro.png" }; // Exemplo de imagens fictícias

                  return {
                      nome: nomeProduto,
                      preco: precosExemplo[nomeProduto] || 0,
                      estoque: estoquesExemplo[nomeProduto] || 0, // Estoque de exemplo
                       imagemUrl: imagemUrlsExemplo[nomeProduto] || '' // Adiciona imagemUrl de exemplo
                  };
              });
              exibirProdutosGaleria(produtosComDetalhesParaGaleria);
         } else {
              console.error("Array 'produtosDisponiveis' também não encontrado ou não é um array no script.js.");
         }
   }
   // ... restante da inicialização ...
   const produtoImagemUrls = {
    "Bolo de Cenoura": "images/bolo-de-cenoura.jpg2.jpg"
    // TODO: Mapear seus outros produtos aqui
};
