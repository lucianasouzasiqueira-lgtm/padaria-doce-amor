// Preços dos produtos
const precos = {
   paoFrances: 0.50,
   bolo: 25.90,
   coxinha: 3.50,
   brigadeiro: 2.00
};

// Função para calcular subtotal
function calcularSubtotal(preco, quantidade) {
   return preco * quantidade;
}

// Sistema de desconto baseado em quantidade
function aplicarDesconto(subtotal, quantidade) {
   let desconto = 0;

   if (quantidade >= 10) {
       desconto = 0.15; // 15% de desconto
   } else if (quantidade >= 5) {
       desconto = 0.10; // 10% de desconto
   } else if (quantidade >= 3) {
       desconto = 0.05; // 5% de desconto
   }

   return subtotal * (1 - desconto);
}

// Cálculo de impostos e taxas
function calcularTotal(subtotal, temEntrega = false) {
   const imposto = 0.08; // 8% de imposto
   const taxaEntrega = 5.00;

   let total = subtotal * (1 + imposto);

   if (temEntrega) {
       total += taxaEntrega;
   }

   return total;
}

// Sistema de troco
function calcularTroco(total, valorPago) {
   if (valorPago < total) {
   	return "Valor insuficiente";
   }
   return valorPago - total;
}

// Sistema de pontos de fidelidade
function calcularPontos(total) {
   return Math.floor(total); // 1 ponto para cada real gasto
}

// Conversor de moeda simples
const taxasCambio = {
   dolar: 5.20,
   euro: 6.10
};

function converterMoeda(valorReal, moeda) {
   return valorReal / taxasCambio[moeda];
}

// Exemplo de uso
let quantidade = 6;
let subtotal = calcularSubtotal(precos.paoFrances, quantidade);
console.log("Subtotal:", subtotal);

let subtotalComDesconto = aplicarDesconto(subtotal, quantidade);
console.log("Com desconto:", subtotalComDesconto);

let total = calcularTotal(subtotalComDesconto, true);
console.log("Total final:", total.toFixed(2));

let valorPago = 10.00;
let troco = calcularTroco(total, valorPago);
console.log("Troco:", troco.toFixed(2));

let pontos = calcularPontos(total);
console.log("Pontos ganhos:", pontos);

let valorDolar = converterMoeda(total, 'dolar');
console.log("Em dólares:", valorDolar.toFixed(2));